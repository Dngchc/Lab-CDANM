#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int book_id;
    char *title;
    char *author;
    int *ratings;
    int ratings_count;
} Book;

typedef struct {
    Book **books;
    int count;
    int capacity;
} Library;

// Tạo Library mới
Library *create_library(int capacity) {
    Library *library = (Library *)malloc(sizeof(Library));
    library->books = (Book **)malloc(capacity * sizeof(Book *));
    library->count = 0;
    library->capacity = capacity;
    return library;
}

// Thêm sách vào Library
void add_book(Library *library, int book_id, const char *title, const char *author, int *ratings, int ratings_count) {
    if (library->count >= library->capacity) {
        printf("Library is full\n");
        return;
    }
    Book *book = (Book *)malloc(sizeof(Book));
    book->book_id = book_id;
    book->title = strdup(title);
    book->author = strdup(author);
    book->ratings = (int *)malloc(ratings_count * sizeof(int));
    memcpy(book->ratings, ratings, ratings_count * sizeof(int)); 
    book->ratings_count = ratings_count;
    library->books[library->count++] = book;
}

Book *find_book(Library *library, int book_id) {
    for (int i = 0; i <= library->count; i++) {
        if (library->books[i]->book_id == book_id) {
            return library->books[i];
        }
    }

